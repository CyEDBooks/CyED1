package structures;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TablaHashTest {

    private TablaHash<Integer> tabla;

    @BeforeEach
    void setUp() {
        tabla = new TablaHash<>(7);   //h(k) = k % 7
    }

    //─────────────────────────────────────────────────────
    //getSize
    //─────────────────────────────────────────────────────

    @Test
    void getSize() {
        //Tamaño configurado en el constructor
        assertEquals(7, tabla.getSize(), "Tamaño debe ser 7");

        //No cambia con inserciones ni deletes
        tabla.insert(1, 10);
        assertEquals(7, tabla.getSize(), "getSize no cambia tras insert");

        tabla.delete(1, 10);
        assertEquals(7, tabla.getSize(), "getSize no cambia tras delete");

        //Distinto tamaño
        TablaHash<String> otra = new TablaHash<>(13);
        assertEquals(13, otra.getSize());
    }

    //─────────────────────────────────────────────────────
    //insert
    //─────────────────────────────────────────────────────

    @Test
    void insert() {
        //Inserción básica: el valor debe poder encontrarse
        tabla.insert(3, 30);
        assertTrue(tabla.search(3, 30), "Valor recién insertado debe encontrarse");

        //Múltiples valores para la misma clave (multimapa)
        tabla.insert(10, 100);
        tabla.insert(10, 101);
        assertTrue(tabla.search(10, 100), "Primer valor de clave 10 debe encontrarse");
        assertTrue(tabla.search(10, 101), "Segundo valor de clave 10 debe encontrarse");

        //Colisión de hash: claves distintas que van al mismo slot
        //h(10) = 10%7 = 3  y  h(17) = 17%7 = 3
        tabla.insert(17, 170);
        assertTrue(tabla.search(10, 100), "Valor de clave 10 debe seguir tras colisión");
        assertTrue(tabla.search(17, 170), "Valor de clave 17 debe encontrarse en el mismo slot");

        //Insertar un valor en slot que ya existe con encadenamiento separado
        tabla.insert(24, 240);   //h(24) = 24%7 = 3  → tercer elemento en slot 3
        assertTrue(tabla.search(24, 240), "Tercer elemento en slot con colisión debe encontrarse");

        //Clave negativa: debe funcionar sin excepción (Math.abs en hashFunction)
        tabla.insert(-5, 55);
        assertTrue(tabla.search(-5, 55), "Clave negativa debe insertarse correctamente");
    }

    //─────────────────────────────────────────────────────
    //search
    //─────────────────────────────────────────────────────

    @Test
    void search() {
        //Slot vacío → false
        assertFalse(tabla.search(0, 99), "search en slot vacío debe retornar false");

        tabla.insert(10, 100);
        tabla.insert(17, 170);   //colisión en slot 3
        tabla.insert(3,  30);
        tabla.insert(24, 240);

        //Valores existentes → true
        assertTrue(tabla.search(10, 100), "search debe encontrar (10,100)");
        assertTrue(tabla.search(17, 170), "search debe encontrar (17,170)");
        assertTrue(tabla.search(3,   30), "search debe encontrar (3,30)");
        assertTrue(tabla.search(24, 240), "search debe encontrar (24,240)");

        //Valor correcto en slot correcto pero par no existe → false
        assertFalse(tabla.search(10, 999), "Valor incorrecto para clave 10 → false");
        assertFalse(tabla.search(3,   99), "Valor incorrecto para clave 3 → false");

        //Clave que no existe → false
        assertFalse(tabla.search(5, 50), "Clave 5 nunca insertada → false");

        //TablaHash<String> para verificar generics
        TablaHash<String> ts = new TablaHash<>(5);
        ts.insert(1, "alice");
        ts.insert(6, "bob");   //h(6)=6%5=1 → colisión con alice
        assertTrue(ts.search(1, "alice"), "String: search(1,alice)");
        assertTrue(ts.search(6, "bob"),   "String: search(6,bob)");
        assertFalse(ts.search(1, "nadie"), "String: valor no insertado → false");
    }

    //─────────────────────────────────────────────────────
    //delete
    //─────────────────────────────────────────────────────

    @Test
    void delete() {
        tabla.insert(10, 100);
        tabla.insert(17, 170);   //colisión en slot 3
        tabla.insert(10, 101);   //segundo valor de clave 10

        //Eliminar uno de los valores de clave 10
        tabla.delete(10, 100);
        assertFalse(tabla.search(10, 100), "Valor eliminado no debe encontrarse");

        //Los demás elementos del slot deben permanecer intactos
        assertTrue(tabla.search(17, 170), "Elemento colisionado debe seguir intacto");
        assertTrue(tabla.search(10, 101), "Segundo valor de clave 10 debe seguir intacto");

        //Eliminar el elemento restante de clave 10
        tabla.delete(10, 101);
        assertFalse(tabla.search(10, 101), "Segundo valor también eliminado");
        assertTrue(tabla.search(17, 170),  "clave 17 sigue intacta");

        //Delete en slot vacío no lanza excepción
        assertDoesNotThrow(() -> tabla.delete(5, 50),
                "delete en slot vacío no debe lanzar excepción");

        //Delete de valor que no existe en slot ocupado → no lanza excepción
        tabla.insert(3, 30);
        assertDoesNotThrow(() -> tabla.delete(3, 999),
                "delete de valor inexistente en slot ocupado no debe lanzar excepción");
        assertTrue(tabla.search(3, 30), "Elemento original debe seguir tras delete fallido");

        //Verificar con tipo String
        TablaHash<String> ts = new TablaHash<>(5);
        ts.insert(1, "alice");
        ts.insert(1, "bob");
        ts.delete(1, "alice");
        assertFalse(ts.search(1, "alice"), "alice eliminada");
        assertTrue(ts.search(1, "bob"),    "bob intacto");
    }
}
