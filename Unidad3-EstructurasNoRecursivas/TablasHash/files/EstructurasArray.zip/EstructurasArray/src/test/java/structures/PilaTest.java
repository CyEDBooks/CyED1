package structures;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PilaTest {

    //Pila de Integer con capacidad 5, compartida como fixture
    private Pila<Integer> pila;

    @BeforeEach
    void setUp() {
        pila = new Pila<>(5);
    }

    //─────────────────────────────────────────────────────
    //stackEmpty
    //─────────────────────────────────────────────────────

    @Test
    void stackEmpty() {
        //Recién creada → vacía
        assertTrue(pila.stackEmpty(), "Pila nueva debe estar vacía");

        //Con un elemento → no vacía
        pila.push(10);
        assertFalse(pila.stackEmpty(), "Pila con un elemento no debe estar vacía");

        //Después de vaciarla de nuevo → vacía
        pila.pop();
        assertTrue(pila.stackEmpty(), "Pila vaciada debe reportar vacía");
    }

    //─────────────────────────────────────────────────────
    //getTop
    //─────────────────────────────────────────────────────

    @Test
    void getTop() {
        //Sin elementos top debe ser 0
        assertEquals(0, pila.getTop(), "top inicial debe ser 0");

        //Cada push incrementa top
        pila.push(1); assertEquals(1, pila.getTop());
        pila.push(2); assertEquals(2, pila.getTop());
        pila.push(3); assertEquals(3, pila.getTop());

        //Cada pop decrementa top
        pila.pop();   assertEquals(2, pila.getTop());
        pila.pop();   assertEquals(1, pila.getTop());
        pila.pop();   assertEquals(0, pila.getTop());
    }

    //─────────────────────────────────────────────────────
    //getSize
    //─────────────────────────────────────────────────────

    @Test
    void getSize() {
        //Capacidad configurada en el constructor
        assertEquals(5, pila.getSize(), "Capacidad debe ser 5");

        //Capacidad no cambia después de push/pop
        pila.push(99);
        assertEquals(5, pila.getSize(), "Capacidad no cambia tras push");

        pila.pop();
        assertEquals(5, pila.getSize(), "Capacidad no cambia tras pop");

        //Pila creada con distinta capacidad
        Pila<String> otra = new Pila<>(10);
        assertEquals(10, otra.getSize());
    }

    //─────────────────────────────────────────────────────
    //getArreglo
    //─────────────────────────────────────────────────────

    @Test
    void getArreglo() {
        Object[] arr = pila.getArreglo();

        //El arreglo existe y tiene la capacidad correcta
        assertNotNull(arr, "El arreglo interno no debe ser null");
        assertEquals(5, arr.length, "Longitud del arreglo debe ser 5");

        //Después de un push, el valor aparece en la posición correcta
        pila.push(42);
        assertEquals(42, pila.getArreglo()[0], "Primer push ocupa índice 0");

        pila.push(99);
        assertEquals(99, pila.getArreglo()[1], "Segundo push ocupa índice 1");

        //Después de pop, la celda liberada pasa a null (GC)
        pila.pop();
        assertNull(pila.getArreglo()[1], "Posición liberada por pop debe ser null");
    }

    //─────────────────────────────────────────────────────
    //push
    //─────────────────────────────────────────────────────

    @Test
    void push() {
        //Push básico: top avanza y el valor queda en el tope
        pila.push(10);
        assertEquals(10, pila.peek(), "Valor recién apilado debe estar en el tope");
        assertEquals(1, pila.getTop());

        //Varios pushes: el último es siempre el tope (LIFO)
        pila.push(20);
        pila.push(30);
        assertEquals(30, pila.peek(), "Último push debe ser el nuevo tope");
        assertEquals(3, pila.getTop());

        //Overflow: StackOverflowError al superar la capacidad
        pila.push(40);
        pila.push(50); //pila llena (top = 5 = size)
        assertThrows(StackOverflowError.class, () -> pila.push(99),
                "Push en pila llena debe lanzar StackOverflowError");

        //La pila NO se modificó tras el overflow
        assertEquals(5, pila.getTop(), "top no debe cambiar tras overflow");
        assertEquals(50, pila.peek(), "tope no debe cambiar tras overflow");
    }

    //─────────────────────────────────────────────────────
    //pop
    //─────────────────────────────────────────────────────

    @Test
    void pop() {
        //Underflow: EmptyStackException en pila vacía
        assertThrows(java.util.EmptyStackException.class, () -> pila.pop(),
                "Pop en pila vacía debe lanzar EmptyStackException");

        //Push de varios elementos y verificar orden LIFO
        pila.push(10);
        pila.push(20);
        pila.push(30);

        assertEquals(30, pila.pop(), "Pop debe extraer el último apilado (LIFO)");
        assertEquals(20, pila.pop());
        assertEquals(10, pila.pop());

        //Después de vaciar, stackEmpty debe ser true
        assertTrue(pila.stackEmpty(), "Pila debe quedar vacía");

        //Pop en pila ya vacía después de usarla → underflow
        assertThrows(java.util.EmptyStackException.class, () -> pila.pop());
    }

    //─────────────────────────────────────────────────────
    //peek
    //─────────────────────────────────────────────────────

    @Test
    void peek() {
        //Underflow: EmptyStackException en pila vacía
        assertThrows(java.util.EmptyStackException.class, () -> pila.peek(),
                "Peek en pila vacía debe lanzar EmptyStackException");

        pila.push(10);
        pila.push(20);

        //Peek retorna el tope sin modificar la pila
        assertEquals(20, pila.peek(), "Peek debe retornar el tope");
        assertEquals(2, pila.getTop(), "Peek no debe modificar top");
        assertEquals(20, pila.peek(), "Peek repetido debe dar el mismo resultado");

        //Después de pop, peek refleja el nuevo tope
        pila.pop();
        assertEquals(10, pila.peek(), "Peek debe actualizarse tras pop");
    }

    //─────────────────────────────────────────────────────
    //toString
    //─────────────────────────────────────────────────────

    @Test
    void testToString() {
        //Pila vacía
        assertEquals("Pila: []", pila.toString(), "toString en pila vacía");

        //Con elementos: el tope aparece al final (derecha)
        pila.push(1);
        pila.push(2);
        pila.push(3);
        String s = pila.toString();
        assertTrue(s.contains("1"), "toString debe mostrar el primer elemento");
        assertTrue(s.contains("2"), "toString debe mostrar el segundo elemento");
        assertTrue(s.contains("3"), "toString debe mostrar el tercer elemento (tope)");

        //El orden correcto en el String: base a tope (izquierda a derecha)
        int pos1 = s.indexOf("1");
        int pos2 = s.indexOf("2");
        int pos3 = s.indexOf("3");
        assertTrue(pos1 < pos2 && pos2 < pos3,
                "toString debe mostrar elementos de base (izq) a tope (der)");
    }
}
