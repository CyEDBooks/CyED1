package structures;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ListaEnlazadaGenericaTest {

    private ListaEnlazadaGenerica<Integer> lista;

    @BeforeEach
    void setUp() {
        lista = new ListaEnlazadaGenerica<>();
    }

    //─────────────────────────────────────────────────────
    //agregar
    //─────────────────────────────────────────────────────

    @Test
    void agregar() {
        //La lista empieza vacía
        assertEquals(0, lista.size(), "Lista nueva debe tener size 0");

        //Agregar incrementa size
        lista.agregar(10);
        assertEquals(1, lista.size(), "size debe ser 1 tras primer agregar");

        lista.agregar(20);
        lista.agregar(30);
        assertEquals(3, lista.size(), "size debe ser 3 tras tres agregar");

        //Los valores son accesibles por índice
        //(el orden depende de la implementación: al frente o al final)
        //Verificamos que todos existan sin asumir posición
        boolean tiene10 = false, tiene20 = false, tiene30 = false;
        for (int i = 0; i < lista.size(); i++) {
            int v = lista.obtener(i);
            if (v == 10) tiene10 = true;
            if (v == 20) tiene20 = true;
            if (v == 30) tiene30 = true;
        }
        assertTrue(tiene10, "Lista debe contener 10");
        assertTrue(tiene20, "Lista debe contener 20");
        assertTrue(tiene30, "Lista debe contener 30");

        //Tipo genérico: funciona con String también
        ListaEnlazadaGenerica<String> ls = new ListaEnlazadaGenerica<>();
        ls.agregar("hola");
        ls.agregar("mundo");
        assertEquals(2, ls.size());
        assertFalse(ls.estaVacia());
    }

    //─────────────────────────────────────────────────────
    //obtener
    //─────────────────────────────────────────────────────

    @Test
    void obtener() {
        lista.agregar(100);
        lista.agregar(200);
        lista.agregar(300);

        //Los tres elementos son accesibles por índice 0, 1, 2
        //Recorremos y verificamos que aparezcan todos
        int suma = 0;
        for (int i = 0; i < lista.size(); i++) {
            suma += lista.obtener(i);
        }
        assertEquals(600, suma, "Suma de todos los elementos debe ser 600");

        //El mismo índice retorna siempre el mismo valor (sin efectos secundarios)
        int primero = lista.obtener(0);
        assertEquals(primero, lista.obtener(0), "obtener no debe modificar la lista");
        assertEquals(3, lista.size(), "size no debe cambiar tras obtener");

        //Un único elemento → solo índice 0 válido
        ListaEnlazadaGenerica<String> uno = new ListaEnlazadaGenerica<>();
        uno.agregar("único");
        assertEquals("único", uno.obtener(0));
    }

    //─────────────────────────────────────────────────────
    //size
    //─────────────────────────────────────────────────────

    @Test
    void size() {
        //Lista vacía → size 0
        assertEquals(0, lista.size(), "size inicial debe ser 0");

        //Crece con agregar
        lista.agregar(1); assertEquals(1, lista.size());
        lista.agregar(2); assertEquals(2, lista.size());
        lista.agregar(3); assertEquals(3, lista.size());

        //Decrece con eliminar
        lista.eliminar(0); assertEquals(2, lista.size());
        lista.eliminar(0); assertEquals(1, lista.size());
        lista.eliminar(0); assertEquals(0, lista.size());

        //Vuelve a crecer tras agregar de nuevo
        lista.agregar(99);
        assertEquals(1, lista.size(), "size debe volver a crecer tras agregar");
    }

    //─────────────────────────────────────────────────────
    //estaVacia
    //─────────────────────────────────────────────────────

    @Test
    void estaVacia() {
        //Recién creada → vacía
        assertTrue(lista.estaVacia(), "Lista nueva debe estar vacía");

        //Con un elemento → no vacía
        lista.agregar(1);
        assertFalse(lista.estaVacia(), "Lista con elemento no debe estar vacía");

        //Al eliminar el único elemento → vacía de nuevo
        lista.eliminar(0);
        assertTrue(lista.estaVacia(), "Lista vaciada debe reportar vacía");

        //Agregar y eliminar varios → verificar consistencia
        lista.agregar(10);
        lista.agregar(20);
        lista.eliminar(0);
        assertFalse(lista.estaVacia(), "Lista con un elemento restante no debe estar vacía");
        lista.eliminar(0);
        assertTrue(lista.estaVacia(), "Lista sin elementos debe estar vacía");
    }

    //─────────────────────────────────────────────────────
    //eliminar
    //─────────────────────────────────────────────────────

    @Test
    void eliminar() {
        lista.agregar(10);
        lista.agregar(20);
        lista.agregar(30);

        //Eliminar el elemento en índice 0 (frente) reduce el size
        lista.eliminar(0);
        assertEquals(2, lista.size(), "size debe decrementar tras eliminar");

        //El elemento eliminado ya no puede obtenerse en la misma posición
        //(otro elemento ocupa su lugar)
        //Verificamos que la suma de los restantes no incluye al eliminado
        int sumaRestantes = 0;
        for (int i = 0; i < lista.size(); i++) {
            sumaRestantes += lista.obtener(i);
        }
        //Si se eliminó 10, la suma de {20,30} = 50
        //Si se eliminó 20, la suma de {10,30} = 40
        //Si se eliminó 30, la suma de {10,20} = 30
        //En cualquier caso, 600 - suma_eliminada = sumaRestantes
        assertTrue(sumaRestantes == 50 || sumaRestantes == 40 || sumaRestantes == 30,
                "La suma restante debe coincidir con la eliminación de un elemento");

        //Eliminar hasta vaciar
        lista.eliminar(0);
        lista.eliminar(0);
        assertTrue(lista.estaVacia(), "Lista debe quedar vacía tras eliminar todos");

        //Se puede volver a usar tras vaciarla
        lista.agregar(999);
        assertEquals(1, lista.size(), "Lista debe funcionar tras vaciarse completamente");
        assertEquals(999, lista.obtener(0));

        //Eliminar el único elemento
        lista.eliminar(0);
        assertTrue(lista.estaVacia());
    }
}
