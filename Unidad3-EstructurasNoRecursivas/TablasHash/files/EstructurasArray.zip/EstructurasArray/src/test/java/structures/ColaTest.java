package structures;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ColaTest {

    private Cola<Integer> cola;

    @BeforeEach
    void setUp() {
        cola = new Cola<>(5);
    }

    //─────────────────────────────────────────────────────
    //queueEmpty
    //─────────────────────────────────────────────────────

    @Test
    void queueEmpty() {
        //Recién creada → vacía
        assertTrue(cola.queueEmpty(), "Cola nueva debe estar vacía");

        //Con un elemento → no vacía
        cola.enqueue(1);
        assertFalse(cola.queueEmpty(), "Cola con elemento no debe estar vacía");

        //Después de sacar el único elemento → vacía de nuevo
        cola.dequeue();
        assertTrue(cola.queueEmpty(), "Cola vaciada debe reportar vacía");
    }

    //─────────────────────────────────────────────────────
    //getSize
    //─────────────────────────────────────────────────────

    @Test
    void getSize() {
        //Cola vacía → size 0
        assertEquals(0, cola.getSize(), "size inicial debe ser 0");

        //Cada enqueue incrementa size
        cola.enqueue(10); assertEquals(1, cola.getSize());
        cola.enqueue(20); assertEquals(2, cola.getSize());
        cola.enqueue(30); assertEquals(3, cola.getSize());

        //Cada dequeue decrementa size
        cola.dequeue(); assertEquals(2, cola.getSize());
        cola.dequeue(); assertEquals(1, cola.getSize());
        cola.dequeue(); assertEquals(0, cola.getSize());
    }

    //─────────────────────────────────────────────────────
    //getSize_max
    //─────────────────────────────────────────────────────

    @Test
    void getSize_max() {
        //Capacidad configurada en el constructor
        assertEquals(5, cola.getSize_max(), "Capacidad debe ser 5");

        //La capacidad no cambia con enqueue/dequeue
        cola.enqueue(1);
        assertEquals(5, cola.getSize_max(), "Capacidad no cambia tras enqueue");

        cola.dequeue();
        assertEquals(5, cola.getSize_max(), "Capacidad no cambia tras dequeue");

        //Distinta capacidad
        Cola<String> otra = new Cola<>(3);
        assertEquals(3, otra.getSize_max());
    }

    //─────────────────────────────────────────────────────
    //getHead
    //─────────────────────────────────────────────────────

    @Test
    void getHead() {
        //Recién creada: head = 1 (base 1)
        assertEquals(1, cola.getHead(), "head inicial debe ser 1");

        //Enqueue no mueve head
        cola.enqueue(10);
        cola.enqueue(20);
        assertEquals(1, cola.getHead(), "enqueue no debe mover head");

        //Dequeue avanza head
        cola.dequeue();
        assertEquals(2, cola.getHead(), "head debe avanzar tras dequeue");

        cola.dequeue();
        assertEquals(3, cola.getHead(), "head debe avanzar de nuevo");
    }

    //─────────────────────────────────────────────────────
    //getTail
    //─────────────────────────────────────────────────────

    @Test
    void getTail() {
        //Recién creada: tail = 1 (base 1)
        assertEquals(1, cola.getTail(), "tail inicial debe ser 1");

        //Cada enqueue avanza tail
        cola.enqueue(10); assertEquals(2, cola.getTail());
        cola.enqueue(20); assertEquals(3, cola.getTail());
        cola.enqueue(30); assertEquals(4, cola.getTail());

        //Dequeue no mueve tail
        cola.dequeue();
        assertEquals(4, cola.getTail(), "dequeue no debe mover tail");

        //Comportamiento circular: tail vuelve a 1 al llegar a size_max
        cola.enqueue(40); //tail=5
        cola.enqueue(50); //tail=5+1=6, pero size_max=5 → da vuelta a 1
        assertEquals(1, cola.getTail(), "tail debe circular al llegar a size_max");
    }

    //─────────────────────────────────────────────────────
    //getArreglo
    //─────────────────────────────────────────────────────

    @Test
    void getArreglo() {
        Object[] arr = cola.getArreglo();

        //El arreglo existe y tiene la longitud correcta
        assertNotNull(arr, "El arreglo interno no debe ser null");
        assertEquals(5, arr.length, "Longitud del arreglo debe ser 5");

        //Enqueue coloca el valor en la posición tail-1
        cola.enqueue(77);
        assertEquals(77, cola.getArreglo()[0], "Primer enqueue debe ocupar índice 0");

        cola.enqueue(88);
        assertEquals(88, cola.getArreglo()[1], "Segundo enqueue debe ocupar índice 1");

        //Dequeue libera la celda (null)
        cola.dequeue();
        assertNull(cola.getArreglo()[0], "Posición liberada por dequeue debe ser null");
    }

    //─────────────────────────────────────────────────────
    //enqueue
    //─────────────────────────────────────────────────────

    @Test
    void enqueue() {
        //El frente de la cola es el primer elemento encolado
        cola.enqueue(100);
        assertEquals(100, cola.peek(), "Primer enqueue debe ser el frente");

        //El frente no cambia con más enqueues
        cola.enqueue(200);
        cola.enqueue(300);
        assertEquals(100, cola.peek(), "peek debe seguir siendo el primer encolado");

        //Size crece correctamente
        assertEquals(3, cola.getSize());

        //Overflow: RuntimeException al superar la capacidad
        cola.enqueue(400);
        cola.enqueue(500); //cola llena
        assertThrows(RuntimeException.class, () -> cola.enqueue(999),
                "enqueue en cola llena debe lanzar RuntimeException");

        //La cola NO se modificó tras el overflow
        assertEquals(5, cola.getSize(), "size no debe cambiar tras overflow");
        assertEquals(100, cola.peek(), "frente no debe cambiar tras overflow");
    }

    //─────────────────────────────────────────────────────
    //dequeue
    //─────────────────────────────────────────────────────

    @Test
    void dequeue() {
        //Underflow: NoSuchElementException en cola vacía
        assertThrows(java.util.NoSuchElementException.class, () -> cola.dequeue(),
                "dequeue en cola vacía debe lanzar NoSuchElementException");

        //Verificar orden FIFO: sale en el mismo orden en que entró
        cola.enqueue(1);
        cola.enqueue(2);
        cola.enqueue(3);

        assertEquals(1, cola.dequeue(), "Primer dequeue debe retornar el primer encolado (FIFO)");
        assertEquals(2, cola.dequeue(), "Segundo dequeue debe retornar el segundo encolado");
        assertEquals(3, cola.dequeue(), "Tercer dequeue debe retornar el tercer encolado");

        assertTrue(cola.queueEmpty(), "Cola debe quedar vacía");

        //Underflow tras vaciarla
        assertThrows(java.util.NoSuchElementException.class, () -> cola.dequeue());
    }

    //─────────────────────────────────────────────────────
    //peek
    //─────────────────────────────────────────────────────

    @Test
    void peek() {
        //Underflow: NoSuchElementException en cola vacía
        assertThrows(java.util.NoSuchElementException.class, () -> cola.peek(),
                "peek en cola vacía debe lanzar NoSuchElementException");

        cola.enqueue(10);
        cola.enqueue(20);

        //Peek retorna el frente sin modificar la cola
        assertEquals(10, cola.peek(), "peek debe retornar el frente");
        assertEquals(2, cola.getSize(), "peek no debe modificar size");
        assertEquals(10, cola.peek(), "peek repetido debe dar el mismo resultado");

        //Después de dequeue, peek refleja el nuevo frente
        cola.dequeue();
        assertEquals(20, cola.peek(), "peek debe actualizarse tras dequeue");
    }

    //─────────────────────────────────────────────────────
    //toString
    //─────────────────────────────────────────────────────

    @Test
    void testToString() {
        //Cola vacía
        assertEquals("Cola: []", cola.toString(), "toString en cola vacía");

        //Cola con elementos: orden lógico frente → final
        cola.enqueue(10);
        cola.enqueue(20);
        cola.enqueue(30);
        String s = cola.toString();
        assertTrue(s.contains("10"), "toString debe mostrar primer elemento");
        assertTrue(s.contains("20"), "toString debe mostrar segundo elemento");
        assertTrue(s.contains("30"), "toString debe mostrar tercer elemento");

        //El orden correcto: frente (izquierda) a final (derecha)
        int pos10 = s.indexOf("10");
        int pos20 = s.indexOf("20");
        int pos30 = s.indexOf("30");
        assertTrue(pos10 < pos20 && pos20 < pos30,
                "toString debe mostrar elementos en orden lógico frente→final");

        //Después de dequeue, el toString ya no muestra el primer elemento
        cola.dequeue();
        assertFalse(cola.toString().contains("10"),
                "toString no debe mostrar elementos extraídos");
    }
}
