package structures;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ColaPrioridadTest {

    private ColaPrioridad<String> cp;

    @BeforeEach
    void setUp() {
        cp = new ColaPrioridad<>(5);
    }

    //─────────────────────────────────────────────────────
    //isEmpty
    //─────────────────────────────────────────────────────

    @Test
    void isEmpty() {
        //Recién creada → vacía
        assertTrue(cp.isEmpty(), "Cola nueva debe estar vacía");

        //Con un elemento → no vacía
        cp.insert(3, "tarea");
        assertFalse(cp.isEmpty(), "Cola con elemento no debe estar vacía");

        //Después de extraer el único → vacía de nuevo
        cp.extractMax();
        assertTrue(cp.isEmpty(), "Cola vaciada debe reportar vacía");
    }

    //─────────────────────────────────────────────────────
    //getSize
    //─────────────────────────────────────────────────────

    @Test
    void getSize() {
        //Cola vacía → size 0
        assertEquals(0, cp.getSize(), "size inicial debe ser 0");

        //Cada insert incrementa size
        cp.insert(1, "a"); assertEquals(1, cp.getSize());
        cp.insert(2, "b"); assertEquals(2, cp.getSize());
        cp.insert(3, "c"); assertEquals(3, cp.getSize());

        //Cada extractMax decrementa size
        cp.extractMax(); assertEquals(2, cp.getSize());
        cp.extractMax(); assertEquals(1, cp.getSize());
        cp.extractMax(); assertEquals(0, cp.getSize());
    }

    //─────────────────────────────────────────────────────
    //getSizeMax
    //─────────────────────────────────────────────────────

    @Test
    void getSizeMax() {
        //Capacidad del constructor
        assertEquals(5, cp.getSizeMax(), "Capacidad debe ser 5");

        //No cambia con inserciones o extracciones
        cp.insert(1, "x");
        assertEquals(5, cp.getSizeMax());

        cp.extractMax();
        assertEquals(5, cp.getSizeMax());

        //Distinta capacidad
        ColaPrioridad<Integer> otra = new ColaPrioridad<>(10);
        assertEquals(10, otra.getSizeMax());
    }

    //─────────────────────────────────────────────────────
    //getValores
    //─────────────────────────────────────────────────────

    @Test
    void getValores() {
        //El arreglo existe y tiene la longitud de la capacidad
        Object[] vals = cp.getValores();
        assertNotNull(vals, "getValores no debe retornar null");
        assertEquals(5, vals.length, "Longitud debe ser size_max");

        //Después de insertar, el arreglo interno refleja los valores
        cp.insert(1, "log");
        cp.insert(5, "alarma");
        Object[] actualizado = cp.getValores();
        //"alarma" tiene mayor prioridad → está en size-1 = índice 1
        assertEquals("alarma", actualizado[1],
                "Elemento de mayor prioridad debe estar en índice size-1");
        assertEquals("log", actualizado[0],
                "Elemento de menor prioridad debe estar en índice 0");
    }

    //─────────────────────────────────────────────────────
    //getPrioridades
    //─────────────────────────────────────────────────────

    @Test
    void getPrioridades() {
        //El arreglo existe
        int[] prios = cp.getPrioridades();
        assertNotNull(prios, "getPrioridades no debe retornar null");
        assertEquals(5, prios.length, "Longitud debe ser size_max");

        //Insertar elementos y verificar el orden ascendente del arreglo
        cp.insert(7, "servidor");
        cp.insert(2, "log");
        cp.insert(9, "alarma");

        int[] p = cp.getPrioridades();
        //Índices 0,1,2 deben estar en orden ascendente: 2, 7, 9
        assertEquals(2, p[0], "Menor prioridad en índice 0");
        assertEquals(7, p[1], "Prioridad media en índice 1");
        assertEquals(9, p[2], "Mayor prioridad en índice 2 (size-1)");
    }

    //─────────────────────────────────────────────────────
    //insert
    //─────────────────────────────────────────────────────

    @Test
    void insert() {
        //El arreglo se mantiene ordenado ascendente por prioridad
        cp.insert(5, "backup");
        cp.insert(1, "log");
        cp.insert(9, "alarma");
        cp.insert(3, "impresora");

        //El mayor siempre es el tope (peek)
        assertEquals("alarma", cp.peek(),
                "Elemento de mayor prioridad debe estar en el tope");

        //El orden de extracción debe ser descendente de prioridad
        assertEquals("alarma",    cp.extractMax()); //p=9
        assertEquals("backup",    cp.extractMax()); //p=5
        assertEquals("impresora", cp.extractMax()); //p=3
        assertEquals("log",       cp.extractMax()); //p=1

        //Overflow: RuntimeException al superar la capacidad
        ColaPrioridad<String> llena = new ColaPrioridad<>(2);
        llena.insert(1, "a");
        llena.insert(2, "b");
        assertThrows(RuntimeException.class, () -> llena.insert(3, "c"),
                "insert en cola llena debe lanzar RuntimeException");

        //La cola NO se modificó
        assertEquals(2, llena.getSize(), "size no debe cambiar tras overflow");

        //Prioridades duplicadas: ambos elementos deben coexistir
        ColaPrioridad<String> dup = new ColaPrioridad<>(3);
        dup.insert(4, "tarea-A");
        dup.insert(4, "tarea-B");
        assertEquals(2, dup.getSize(), "Ambas entradas con misma prioridad deben existir");
    }

    //─────────────────────────────────────────────────────
    //peek
    //─────────────────────────────────────────────────────

    @Test
    void peek() {
        //Underflow: NoSuchElementException en cola vacía
        assertThrows(java.util.NoSuchElementException.class, () -> cp.peek(),
                "peek en cola vacía debe lanzar NoSuchElementException");

        cp.insert(3, "impresora");
        cp.insert(7, "servidor");
        cp.insert(1, "log");

        //Peek retorna el de mayor prioridad
        assertEquals("servidor", cp.peek(),
                "peek debe retornar el de mayor prioridad (p=7)");

        //Peek no modifica la cola
        assertEquals(3, cp.getSize(), "peek no debe modificar size");
        assertEquals("servidor", cp.peek(), "peek repetido debe dar el mismo resultado");

        //Después de insertar uno mayor, peek cambia
        cp.insert(9, "alarma");
        assertEquals("alarma", cp.peek(),
                "peek debe actualizarse al insertar un elemento de mayor prioridad");
    }

    //─────────────────────────────────────────────────────
    //extractMax
    //─────────────────────────────────────────────────────

    @Test
    void extractMax() {
        //Underflow: NoSuchElementException en cola vacía
        assertThrows(java.util.NoSuchElementException.class, () -> cp.extractMax(),
                "extractMax en cola vacía debe lanzar NoSuchElementException");

        cp.insert(3, "impresora");
        cp.insert(7, "servidor");
        cp.insert(1, "log");
        cp.insert(9, "alarma");
        cp.insert(5, "backup");

        //Debe salir en orden descendente de prioridad, sin importar el orden de inserción
        assertEquals("alarma",    cp.extractMax()); //p=9
        assertEquals("servidor",  cp.extractMax()); //p=7
        assertEquals("backup",    cp.extractMax()); //p=5
        assertEquals("impresora", cp.extractMax()); //p=3
        assertEquals("log",       cp.extractMax()); //p=1

        //Después de extraer todo, la cola debe estar vacía
        assertTrue(cp.isEmpty(), "Cola debe quedar vacía tras extraer todos");

        //Underflow al intentar extraer de cola vacía
        assertThrows(java.util.NoSuchElementException.class, () -> cp.extractMax());
    }

    //─────────────────────────────────────────────────────
    //toString
    //─────────────────────────────────────────────────────

    @Test
    void testToString() {
        //Cola vacía
        assertEquals("ColaPrioridad: []", cp.toString(), "toString en cola vacía");

        //Cola con elementos: debe listar de mayor a menor prioridad
        cp.insert(1, "log");
        cp.insert(5, "backup");
        cp.insert(9, "alarma");

        String s = cp.toString();
        assertTrue(s.contains("alarma"),  "toString debe mostrar alarma");
        assertTrue(s.contains("backup"),  "toString debe mostrar backup");
        assertTrue(s.contains("log"),     "toString debe mostrar log");
        assertTrue(s.contains("p=9"),     "toString debe mostrar la prioridad 9");
        assertTrue(s.contains("p=5"),     "toString debe mostrar la prioridad 5");
        assertTrue(s.contains("p=1"),     "toString debe mostrar la prioridad 1");

        //El mayor debe aparecer antes que el menor en el String
        assertTrue(s.indexOf("alarma") < s.indexOf("log"),
                "toString debe mostrar de mayor a menor prioridad");
    }
}
