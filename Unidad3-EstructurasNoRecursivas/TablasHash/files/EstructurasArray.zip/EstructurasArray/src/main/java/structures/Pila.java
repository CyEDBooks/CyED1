package structures;

/**
 * Pila genérica LIFO (Last In, First Out) implementada sobre arreglo.
 *
 */
public class Pila<T> {

    private T[]  arreglo;
    private int  top;
    private int  size;

    /**
     * Crea una pila con capacidad máxima {@code n}.
     *
     */
    @SuppressWarnings("unchecked")
    public Pila(int n) {
        this.size    = n;
        this.arreglo = (T[]) new Object[n];
        this.top     = 0;
    }

    //─────────────────────────────────────────────────────
    //Consultas de estado
    //─────────────────────────────────────────────────────

    /**
     * @return {@code true} si la pila no tiene elementos
     */
    public boolean stackEmpty() { return this.top == 0; }

    /** @return número de elementos actuales */
    public int getTop()  { return top;  }

    /** @return capacidad máxima configurada */
    public int getSize() { return size; }

    /** @return referencia al arreglo interno (solo lectura recomendada) */
    public Object[] getArreglo() { return arreglo; }

    //─────────────────────────────────────────────────────
    //Operaciones principales
    //─────────────────────────────────────────────────────

    /**
     * Inserta {@code x} en el tope de la pila.
     *
     * <p><strong>Complejidad: O(1)</strong>
     *
     * @param x elemento a insertar
     * @throws StackOverflowError si la pila está llena
     */
    public void push(T x) {
        if (this.top == this.size)
            throw new StackOverflowError("Overflow: pila llena.");
        this.arreglo[this.top] = x;
        this.top++;
    }

    /**
     * Extrae y retorna el elemento del tope.
     *
     * <p><strong>Complejidad: O(1)</strong>
     *
     * @return elemento en el tope
     * @throws java.util.EmptyStackException si la pila está vacía
     */
    public T pop() {
        if (this.top == 0)
            throw new java.util.EmptyStackException();
        this.top--;
        T val = this.arreglo[this.top];
        this.arreglo[this.top] = null;  //liberar referencia → ayuda al GC
        return val;
    }

    /**
     * Consulta el tope sin extraerlo.
     *
     * <p><strong>Complejidad: O(1)</strong>
     *
     * @return elemento en el tope
     * @throws java.util.EmptyStackException si la pila está vacía
     */
    public T peek() {
        if (this.top == 0)
            throw new java.util.EmptyStackException();
        return this.arreglo[this.top - 1];
    }

    //─────────────────────────────────────────────────────
    //toString
    //─────────────────────────────────────────────────────

    @Override
    public String toString() {
        if (stackEmpty()) return "Pila: []";
        StringBuilder sb = new StringBuilder("Pila (tope →): [");
        for (int i = 0; i < this.top; i++) {
            sb.append(arreglo[i]);
            if (i < this.top - 1) sb.append(", ");
        }
        return sb.append("]").toString();
    }
}
