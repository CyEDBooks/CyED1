package structures;

/**
 * Cola de Prioridad genérica implementada sobre arreglo ordenado.
 *
 * @param <T> tipo del valor almacenado en cada entrada de la cola
 */
public class ColaPrioridad<T> {

    private T[]   valores;
    private int[] prioridades;
    private int   size;
    private int   size_max;

    /**
     * Crea una cola de prioridad con capacidad máxima {@code n}.
     *
     * @param n capacidad máxima (> 0)
     */
    @SuppressWarnings("unchecked")
    public ColaPrioridad(int n) {
        this.size_max    = n;
        this.size        = 0;
        this.valores     = (T[]) new Object[n];
        this.prioridades = new int[n];
    }

    //─────────────────────────────────────────────────────
    //Consultas de estado
    //─────────────────────────────────────────────────────

    /** @return true si la cola no tiene elementos */
    public boolean isEmpty()      { return size == 0;    }

    /** @return número de elementos actuales */
    public int getSize()          { return size;         }

    /** @return capacidad máxima configurada */
    public int getSizeMax()       { return size_max;     }

    /** @return arreglo interno de valores (solo lectura recomendada) */
    public T[] getValores()       { return valores;      }

    /** @return arreglo interno de prioridades (solo lectura recomendada) */
    public int[] getPrioridades() { return prioridades;  }

    //─────────────────────────────────────────────────────
    //Operaciones principales
    //─────────────────────────────────────────────────────

    /**
     * Inserta {@code valor} con prioridad {@code p}.
     *
     * @param p     prioridad del elemento (mayor número = mayor prioridad)
     * @param valor valor a almacenar
     * @throws RuntimeException si la cola está llena (overflow)
     */
    public void insert(int p, T valor) {
        if (size == size_max)
            throw new RuntimeException("Overflow: cola de prioridad llena.");

        int i = size - 1;
        while (i >= 0 && prioridades[i] > p) {
            valores[i + 1]     = valores[i];
            prioridades[i + 1] = prioridades[i];
            i--;
        }
        valores[i + 1]     = valor;
        prioridades[i + 1] = p;
        size++;
    }

    /**
     * Consulta (sin extraer) el elemento de mayor prioridad.
     *
     *
     * @return el valor con mayor prioridad
     * @throws java.util.NoSuchElementException si la cola está vacía
     */
    public T peek() {
        if (size == 0)
            throw new java.util.NoSuchElementException("Cola de prioridad vacía.");
        return valores[size - 1];
    }

    /**
     * Extrae y retorna el elemento de mayor prioridad.
     *
     *
     * @return el valor con mayor prioridad
     * @throws java.util.NoSuchElementException si la cola está vacía (underflow)
     */
    public T extractMax() {
        if (size == 0)
            throw new java.util.NoSuchElementException("Underflow: cola de prioridad vacía.");
        T val = valores[size - 1];
        valores[size - 1] = null;   //liberar referencia → ayuda al GC
        size--;
        return val;
    }

    //─────────────────────────────────────────────────────
    //toString
    //─────────────────────────────────────────────────────

    /** Muestra los elementos de mayor a menor prioridad. */
    @Override
    public String toString() {
        if (isEmpty()) return "ColaPrioridad: []";
        StringBuilder sb = new StringBuilder("ColaPrioridad: [");
        for (int i = size - 1; i >= 0; i--) {
            sb.append("(").append(valores[i])
                    .append(", p=").append(prioridades[i]).append(")");
            if (i > 0) sb.append(", ");
        }
        return sb.append("]").toString();
    }
}
