package structures;

/**
 * Tabla Hash genérica con encadenamiento separado (chaining).
 */
public class TablaHash<V> {

    private ListaEnlazadaGenerica<V>[] tabla;
    private int size;

    /** @return número de slots de la tabla */
    public int getSize() { return size; }

    //─────────────────────────────────────────────────────
    //Constructor
    //─────────────────────────────────────────────────────

    /**
     * Crea una tabla hash con {@code m} slots vacíos.
     *
     * @param m número de slots (primo recomendado para minimizar colisiones)
     */
    @SuppressWarnings("unchecked")
    public TablaHash(int m) {
        this.tabla = new ListaEnlazadaGenerica[m];
        this.size  = m;
    }

    //─────────────────────────────────────────────────────
    //Operaciones principales
    //─────────────────────────────────────────────────────

    /**
     * Inserta {@code value} en el slot correspondiente a la clave {@code k}.
     *
     */
    public void insert(int k, V value) {
        int pos = hashFunction(k);
        if (tabla[pos] == null)
            tabla[pos] = new ListaEnlazadaGenerica<>();
        tabla[pos].agregar(value);
    }

    /**
     * Busca si {@code value} está asociado a la clave {@code k}.
     *
     */
    public boolean search(int k, V value) {
        int pos = hashFunction(k);
        ListaEnlazadaGenerica<V> lista = tabla[pos];
        if (lista == null) return false;
        for (int i = 0; i < lista.size(); i++) {
            //equals() para comparación correcta de objetos genéricos
            if (value.equals(lista.obtener(i))) return true;
        }
        return false;
    }

    /**
     * Elimina la primera ocurrencia de {@code value} asociada a la clave {@code k}.
     * No lanza excepción si el par no existe.
     *
     */
    public void delete(int k, V value) {
        int pos = hashFunction(k);
        ListaEnlazadaGenerica<V> lista = tabla[pos];
        if (lista == null || lista.estaVacia()) return;
        for (int i = 0; i < lista.size(); i++) {
            if (value.equals(lista.obtener(i))) {
                lista.eliminar(i);
                return;
            }
        }
    }

    //─────────────────────────────────────────────────────
    //Función hash
    //─────────────────────────────────────────────────────

    /**
     * Función hash por división: {@code h(k) = k % m}.
     * Usa {@code Math.abs} para manejar claves negativas.
     *
     * @param k clave entera
     * @return índice del slot (0 ≤ resultado &lt; size)
     */
    private int hashFunction(int k) {
        return Math.abs(k % this.size);
    }
}
