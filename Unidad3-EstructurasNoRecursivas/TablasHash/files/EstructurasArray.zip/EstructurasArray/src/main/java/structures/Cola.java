package structures;

/**
 * Cola genérica FIFO (First In, First Out) implementada sobre arreglo circular.
 */
public class Cola<T> {

    private int  head;
    private int  tail;
    private int  size_max;
    private int  size;
    private T[]  arreglo;

    /**
     * Crea una cola circular con capacidad máxima {@code n}.
     *
     * @param n capacidad máxima (> 0)
     */
    @SuppressWarnings("unchecked")
    public Cola(int n) {
        this.head     = 1;
        this.tail     = 1;
        this.size_max = n;
        this.size     = 0;
        this.arreglo  = (T[]) new Object[n];
    }

    //─────────────────────────────────────────────────────
    //Consultas de estado
    //─────────────────────────────────────────────────────

    /** @return {@code true} si la cola no tiene elementos */
    public boolean queueEmpty() { return this.size == 0; }

    /** @return número de elementos actuales */
    public int getSize()     { return size;     }

    /** @return capacidad máxima configurada */
    public int getSize_max() { return size_max; }

    /** @return puntero al frente (base 1) */
    public int getHead()     { return head;     }

    /** @return puntero al siguiente slot libre (base 1) */
    public int getTail()     { return tail;     }

    /** @return referencia al arreglo interno (solo lectura recomendada) */
    public Object[] getArreglo() { return arreglo; }

    //─────────────────────────────────────────────────────
    //Operaciones principales
    //─────────────────────────────────────────────────────

    /**
     * Inserta {@code x} al final de la cola.
     *
     * @param x elemento a insertar
     * @throws RuntimeException si la cola está llena (overflow)
     */
    public void enqueue(T x) {
        if (this.size == this.size_max)
            throw new RuntimeException("Overflow: la cola está llena.");
        this.arreglo[this.tail - 1] = x;
        this.tail = (this.tail == this.size_max) ? 1 : this.tail + 1;
        this.size++;
    }

    /**
     * Extrae y retorna el elemento del frente.
     *
     *
     * @return elemento del frente
     * @throws java.util.NoSuchElementException si la cola está vacía (underflow)
     */
    public T dequeue() {
        if (this.size == 0)
            throw new java.util.NoSuchElementException("Underflow: la cola está vacía.");
        T valor = this.arreglo[this.head - 1];
        this.arreglo[this.head - 1] = null;   //liberar referencia → GC
        this.head = (this.head == this.size_max) ? 1 : this.head + 1;
        this.size--;
        return valor;
    }

    /**
     * Consulta el frente sin extraerlo.
     *
     * @return elemento del frente
     * @throws java.util.NoSuchElementException si la cola está vacía
     */
    public T peek() {
        if (this.size == 0)
            throw new java.util.NoSuchElementException("La cola está vacía.");
        return this.arreglo[this.head - 1];
    }

    //─────────────────────────────────────────────────────
    //toString
    //─────────────────────────────────────────────────────

    /**
     * Vista lógica (frente → final) usando aritmética modular para
     * recorrer el arreglo circular correctamente.
     *
     * <p>Índice físico de cada elemento:
     * <pre>
     *   físico = (head - 1 + i) % size_max
     * </pre>
     */
    @Override
    public String toString() {
        if (queueEmpty()) return "Cola: []";
        StringBuilder sb = new StringBuilder("Cola: [");
        for (int i = 0; i < this.size; i++) {
            int idx = (this.head - 1 + i) % this.size_max;
            sb.append(arreglo[idx]);
            if (i < this.size - 1) sb.append(", ");
        }
        return sb.append("]").toString();
    }
}
