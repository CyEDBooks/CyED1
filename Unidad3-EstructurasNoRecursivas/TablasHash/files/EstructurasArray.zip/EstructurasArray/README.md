# Estructuras genéricas sobre arreglo

Cuatro estructuras de datos genéricas, todas respaldadas por arreglos de capacidad fija (sin redimensionar):

- `Pila<T>` — LIFO, operaciones `push`/`pop`/`peek` en O(1).
- `Cola<T>` — FIFO circular, operaciones `enqueue`/`dequeue`/`peek` en O(1).
- `ColaPrioridad<T>` — arreglo ordenado por prioridad; `insert` en O(n), `extractMax`/`peek` en O(1).
- `TablaHash<V>` — encadenamiento separado sobre `ListaEnlazadaGenerica<T>`, claves `int`.

## Estructura Maven

```
EstructurasArray/
├── pom.xml
├── src/main/java/
│   ├── ui/Main.java                          (demostración de las 4 estructuras)
│   └── structures/
│       ├── Nodo.java
│       ├── ListaEnlazadaGenerica.java
│       ├── Pila.java
│       ├── Cola.java
│       ├── ColaPrioridad.java
│       └── TablaHash.java
└── src/test/java/structures/
    ├── PilaTest.java
    ├── ColaTest.java
    ├── ColaPrioridadTest.java
    ├── TablaHashTest.java
    └── ListaEnlazadaGenericaTest.java
```

## Compilar, probar y ejecutar

```bash
mvn compile
mvn test
mvn exec:java -Dexec.mainClass=ui.Main
```

`Main.java` recorre las 4 estructuras paso a paso: creación, operaciones normales, overflow, underflow y reutilización después de vaciarse, incluyendo una comparación directa entre `Cola` (FIFO) y `ColaPrioridad` con los mismos datos.
